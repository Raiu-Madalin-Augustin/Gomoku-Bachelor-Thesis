﻿namespace Gomoku.Logic
{
  public interface ICoordinates
  {
    public int X { get; }
    public int Y { get; }
  }
}