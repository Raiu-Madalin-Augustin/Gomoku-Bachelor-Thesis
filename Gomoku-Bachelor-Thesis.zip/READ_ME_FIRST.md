Before running the application, you need to do a few steps:
	1. You need to make sure you have a python3 installed
	2. Go to the Gomoku folder and open PythonSettings.txt, on the first row you need to put the full path of the Python Executable
		example:C:\\Python310\\python.exe in order for the Python implementation to work.

Now you can open the project, the .sln is in Gomoku file