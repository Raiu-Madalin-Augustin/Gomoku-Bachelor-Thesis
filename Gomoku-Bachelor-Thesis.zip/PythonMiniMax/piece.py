BLACK = 1
WHITE = -1
EMPTY = 0
symbols = {BLACK: 'X', WHITE: 'O', EMPTY: '.'}